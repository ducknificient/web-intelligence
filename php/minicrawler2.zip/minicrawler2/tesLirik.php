<?php

	require 'misc.php';
	getLyrics();

?>